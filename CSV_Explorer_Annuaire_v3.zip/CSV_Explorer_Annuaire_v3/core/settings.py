from __future__ import annotations

from PySide6.QtCore import QSettings


class AppSettings:
    def __init__(self) -> None:
        self._settings = QSettings("OpenAI", "CSVExplorerAnnuaire")

    def get_last_directory(self) -> str:
        return str(self._settings.value("last_directory", ""))

    def set_last_directory(self, path: str) -> None:
        self._settings.setValue("last_directory", path)

    def get_last_separator(self) -> str:
        return str(self._settings.value("last_separator", ","))

    def set_last_separator(self, value: str) -> None:
        self._settings.setValue("last_separator", value)

    def get_last_encoding(self) -> str:
        return str(self._settings.value("last_encoding", "utf-8"))

    def set_last_encoding(self, value: str) -> None:
        self._settings.setValue("last_encoding", value)

    def get_ignore_errors(self) -> bool:
        value = self._settings.value("ignore_errors", False)
        if isinstance(value, bool):
            return value
        return str(value).lower() in {"1", "true", "yes"}

    def set_ignore_errors(self, value: bool) -> None:
        self._settings.setValue("ignore_errors", bool(value))
