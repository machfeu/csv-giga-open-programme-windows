from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import duckdb


class DatabaseManager:
    TABLE_NAME = "data_cache"
    METADATA_TABLE = "cache_metadata"

    def __init__(self) -> None:
        self.conn: duckdb.DuckDBPyConnection | None = None
        self.db_path: str = ""
        self.columns: list[str] = []

    def connect(self, db_path: str) -> None:
        db_path = str(Path(db_path))
        if self.conn is not None:
            try:
                self.conn.close()
            except Exception:
                pass
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = duckdb.connect(db_path)
        self.db_path = db_path

    def close(self) -> None:
        if self.conn is not None:
            self.conn.close()
            self.conn = None

    def _get_cursor(self) -> duckdb.DuckDBPyConnection:
        if self.conn is None:
            raise RuntimeError("Aucune base DuckDB n'est connectée.")
        return self.conn.cursor()

    def _table_exists(self, table_name: str) -> bool:
        cur = self._get_cursor()
        row = cur.execute(
            """
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema IN ('main', 'temp')
              AND table_name = ?
            LIMIT 1
            """,
            [table_name],
        ).fetchone()
        return row is not None

    def _refresh_columns(self) -> list[str]:
        if not self._table_exists(self.TABLE_NAME):
            self.columns = []
            return self.columns

        cur = self._get_cursor()
        rows = cur.execute(f'DESCRIBE "{self.TABLE_NAME}"').fetchall()
        self.columns = [row[0] for row in rows]
        return self.columns

    def get_columns(self) -> list[str]:
        return self._refresh_columns()

    def is_cache_valid(
        self,
        csv_path: str,
        separator: str,
        encoding: str,
        ignore_errors: bool,
    ) -> bool:
        if self.conn is None:
            return False
        if not self._table_exists(self.TABLE_NAME) or not self._table_exists(self.METADATA_TABLE):
            return False

        csv_file = Path(csv_path)
        if not csv_file.exists():
            return False

        cur = self._get_cursor()
        row = cur.execute(
            f'''
            SELECT source_path, file_size, file_mtime, separator, encoding, ignore_errors
            FROM "{self.METADATA_TABLE}"
            LIMIT 1
            '''
        ).fetchone()
        if row is None:
            return False

        stat = csv_file.resolve().stat()
        expected = (
            str(csv_file.resolve()),
            stat.st_size,
            stat.st_mtime,
            separator,
            encoding,
            bool(ignore_errors),
        )
        actual = (row[0], row[1], row[2], row[3], row[4], bool(row[5]))
        return actual == expected

    def import_csv(
        self,
        csv_path: str,
        separator: str = ",",
        encoding: str = "utf-8",
        ignore_errors: bool = False,
    ) -> list[str]:
        csv_file = Path(csv_path).resolve()
        if not csv_file.exists():
            raise FileNotFoundError(f"Fichier introuvable : {csv_file}")

        cur = self._get_cursor()
        cur.execute(f'DROP TABLE IF EXISTS "{self.TABLE_NAME}"')
        cur.execute(f'DROP TABLE IF EXISTS "{self.METADATA_TABLE}"')

        cur.execute(
            f'''
            CREATE TABLE "{self.TABLE_NAME}" AS
            SELECT *
            FROM read_csv_auto(
                ?,
                delim=?,
                encoding=?,
                ignore_errors=?
            )
            ''',
            [str(csv_file), separator, encoding, bool(ignore_errors)],
        )

        cur.execute(
            f'''
            CREATE TABLE "{self.METADATA_TABLE}" (
                source_path VARCHAR,
                file_size BIGINT,
                file_mtime DOUBLE,
                separator VARCHAR,
                encoding VARCHAR,
                ignore_errors BOOLEAN
            )
            '''
        )
        stat = csv_file.stat()
        cur.execute(
            f'''
            INSERT INTO "{self.METADATA_TABLE}"
            VALUES (?, ?, ?, ?, ?, ?)
            ''',
            [
                str(csv_file),
                stat.st_size,
                stat.st_mtime,
                separator,
                encoding,
                bool(ignore_errors),
            ],
        )
        return self._refresh_columns()

    def _quote_identifier(self, name: str) -> str:
        if name not in self.columns:
            raise ValueError(f"Colonne invalide : {name}")
        return '"' + name.replace('"', '""') + '"'

    @staticmethod
    def _normalize_sort_order(sort_order: str | None) -> str:
        return "DESC" if str(sort_order).upper() == "DESC" else "ASC"

    @staticmethod
    def _normalize_filter_operator(value: str) -> str:
        allowed = {"contient", "égal à", "commence par", "est vide", "n'est pas vide"}
        if value not in allowed:
            raise ValueError(f"Opérateur de filtre invalide : {value}")
        return value

    def _build_where_clause(
        self,
        search_text: str = "",
        filters: Iterable[dict[str, Any]] | None = None,
    ) -> tuple[str, list[Any]]:
        filters = list(filters or [])
        clauses: list[str] = []
        params: list[Any] = []

        search_text = (search_text or "").strip()
        if search_text:
            if not self.columns:
                return "", []
            search_parts = []
            for column in self.columns:
                quoted = self._quote_identifier(column)
                search_parts.append(f"CAST({quoted} AS VARCHAR) ILIKE ?")
                params.append(f"%{search_text}%")
            clauses.append("(" + " OR ".join(search_parts) + ")")

        for flt in filters:
            column_name = str(flt.get("column", ""))
            operator = self._normalize_filter_operator(str(flt.get("op", "")))
            value = "" if flt.get("value") is None else str(flt.get("value"))
            quoted = self._quote_identifier(column_name)

            if operator == "contient":
                clauses.append(f"CAST({quoted} AS VARCHAR) ILIKE ?")
                params.append(f"%{value}%")
            elif operator == "égal à":
                clauses.append(f"CAST({quoted} AS VARCHAR) = ?")
                params.append(value)
            elif operator == "commence par":
                clauses.append(f"CAST({quoted} AS VARCHAR) ILIKE ?")
                params.append(f"{value}%")
            elif operator == "est vide":
                clauses.append(f"({quoted} IS NULL OR CAST({quoted} AS VARCHAR) = '')")
            elif operator == "n'est pas vide":
                clauses.append(f"({quoted} IS NOT NULL AND CAST({quoted} AS VARCHAR) <> '')")

        if not clauses:
            return "", params
        return " WHERE " + " AND ".join(clauses), params

    def _build_order_clause(self, sort_col: str | None, sort_order: str | None) -> str:
        if not sort_col:
            return ""
        quoted = self._quote_identifier(sort_col)
        direction = self._normalize_sort_order(sort_order)
        return f" ORDER BY {quoted} {direction}"

    def get_count(
        self,
        search_text: str = "",
        filters: Iterable[dict[str, Any]] | None = None,
    ) -> int:
        if not self.columns:
            self._refresh_columns()
        where_sql, params = self._build_where_clause(search_text, filters)
        cur = self._get_cursor()
        row = cur.execute(
            f'SELECT COUNT(*) FROM "{self.TABLE_NAME}"{where_sql}',
            params,
        ).fetchone()
        return int(row[0] if row else 0)

    def fetch_page(
        self,
        page_size: int,
        offset: int,
        sort_col: str | None = None,
        sort_order: str | None = "ASC",
        search_text: str = "",
        filters: Iterable[dict[str, Any]] | None = None,
    ) -> list[tuple[Any, ...]]:
        if not self.columns:
            self._refresh_columns()

        page_size = max(1, int(page_size))
        offset = max(0, int(offset))
        where_sql, params = self._build_where_clause(search_text, filters)
        order_sql = self._build_order_clause(sort_col, sort_order)

        cur = self._get_cursor()
        return cur.execute(
            f'''
            SELECT *
            FROM "{self.TABLE_NAME}"{where_sql}{order_sql}
            LIMIT ? OFFSET ?
            ''',
            [*params, page_size, offset],
        ).fetchall()

    def export_csv(
        self,
        output_path: str,
        search_text: str = "",
        filters: Iterable[dict[str, Any]] | None = None,
        sort_col: str | None = None,
        sort_order: str | None = "ASC",
    ) -> None:
        if not self.columns:
            self._refresh_columns()

        where_sql, params = self._build_where_clause(search_text, filters)
        order_sql = self._build_order_clause(sort_col, sort_order)
        cur = self._get_cursor()
        cur.execute(
            f'''
            COPY (
                SELECT *
                FROM "{self.TABLE_NAME}"{where_sql}{order_sql}
            ) TO ? (HEADER, DELIMITER ',')
            ''',
            [*params, str(Path(output_path))],
        )
