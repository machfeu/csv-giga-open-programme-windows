from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)


class FilterDialog(QDialog):
    def __init__(self, columns: list[str], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Ajouter un filtre")
        self.setMinimumWidth(340)

        layout = QVBoxLayout(self)

        self.column_combo = QComboBox()
        self.column_combo.addItems(columns)

        self.operator_combo = QComboBox()
        self.operator_combo.addItems(
            ["contient", "égal à", "commence par", "est vide", "n'est pas vide"]
        )
        self.operator_combo.currentTextChanged.connect(self._update_value_state)

        self.value_edit = QLineEdit()
        self.value_edit.setPlaceholderText("Valeur du filtre")

        layout.addWidget(QLabel("Colonne"))
        layout.addWidget(self.column_combo)
        layout.addWidget(QLabel("Opérateur"))
        layout.addWidget(self.operator_combo)
        layout.addWidget(QLabel("Valeur"))
        layout.addWidget(self.value_edit)

        buttons = QHBoxLayout()
        ok_button = QPushButton("Appliquer")
        cancel_button = QPushButton("Annuler")
        ok_button.clicked.connect(self._on_accept)
        cancel_button.clicked.connect(self.reject)
        buttons.addWidget(ok_button)
        buttons.addWidget(cancel_button)
        layout.addLayout(buttons)

        self._update_value_state(self.operator_combo.currentText())

    def _update_value_state(self, operator: str) -> None:
        needs_value = operator not in {"est vide", "n'est pas vide"}
        self.value_edit.setEnabled(needs_value)
        if not needs_value:
            self.value_edit.clear()

    def _on_accept(self) -> None:
        operator = self.operator_combo.currentText()
        if operator not in {"est vide", "n'est pas vide"} and not self.value_edit.text().strip():
            QMessageBox.warning(self, "Filtre incomplet", "Merci de saisir une valeur pour ce filtre.")
            return
        self.accept()

    def get_filter(self) -> dict[str, str]:
        return {
            "column": self.column_combo.currentText(),
            "op": self.operator_combo.currentText(),
            "value": self.value_edit.text().strip(),
        }
