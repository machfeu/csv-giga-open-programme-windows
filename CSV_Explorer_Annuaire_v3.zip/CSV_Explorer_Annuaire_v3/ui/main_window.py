from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pyperclip
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QStatusBar,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from core.database import DatabaseManager
from core.settings import AppSettings
from core.worker import DbWorker
from ui.detail_dialog import DetailDialog
from ui.filter_dialog import FilterDialog
from ui.table_model import CSVTableModel


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        self.db = DatabaseManager()
        self.settings = AppSettings()

        self.current_csv_path = ""
        self.current_page = 0
        self.page_size = 100
        self.total_count = 0
        self.sort_col: str | None = None
        self.sort_order = "ASC"
        self.filters: list[dict[str, str]] = []
        self.search_text = ""
        self.worker: DbWorker | None = None

        self.setWindowTitle("CSV Explorer Annuaire")
        self.resize(1280, 820)

        self._build_ui()
        self._load_saved_preferences()
        self._update_navigation_state()

    def _build_ui(self) -> None:
        central = QWidget(self)
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)

        import_bar = QHBoxLayout()
        self.import_button = QPushButton("Importer un CSV")
        self.import_button.clicked.connect(self.on_import_click)

        self.separator_combo = QComboBox()
        self.separator_combo.addItems([",", ";", "\\t"])

        self.encoding_combo = QComboBox()
        self.encoding_combo.addItems(["utf-8", "latin-1", "utf-16"])

        self.ignore_errors_checkbox = QCheckBox("Ignorer les lignes en erreur")
        self.ignore_errors_checkbox.setToolTip(
            "DuckDB peut ignorer les lignes défectueuses. Désactivé par défaut pour éviter les pertes silencieuses."
        )

        import_bar.addWidget(self.import_button)
        import_bar.addWidget(QLabel("Séparateur"))
        import_bar.addWidget(self.separator_combo)
        import_bar.addWidget(QLabel("Encodage"))
        import_bar.addWidget(self.encoding_combo)
        import_bar.addWidget(self.ignore_errors_checkbox)
        import_bar.addStretch()

        main_layout.addLayout(import_bar)

        action_bar = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Recherche globale puis Entrée")
        self.search_edit.returnPressed.connect(self.apply_search)

        self.add_filter_button = QPushButton("Ajouter un filtre")
        self.add_filter_button.clicked.connect(self.add_filter)

        self.reset_button = QPushButton("Réinitialiser")
        self.reset_button.clicked.connect(self.reset_filters)

        self.export_button = QPushButton("Exporter les résultats")
        self.export_button.clicked.connect(self.export_results)

        action_bar.addWidget(self.search_edit)
        action_bar.addWidget(self.add_filter_button)
        action_bar.addWidget(self.reset_button)
        action_bar.addWidget(self.export_button)

        main_layout.addLayout(action_bar)

        self.file_info_label = QLabel("Aucun fichier chargé")
        self.file_info_label.setStyleSheet("font-weight: 600;")
        main_layout.addWidget(self.file_info_label)

        chips_container = QWidget()
        self.filter_layout = QHBoxLayout(chips_container)
        self.filter_layout.setContentsMargins(0, 0, 0, 0)
        self.filter_layout.setSpacing(6)

        chips_scroll = QScrollArea()
        chips_scroll.setWidgetResizable(True)
        chips_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        chips_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        chips_scroll.setFixedHeight(46)
        chips_scroll.setWidget(chips_container)
        main_layout.addWidget(chips_scroll)

        self.table_view = QTableView()
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table_view.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_view.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table_view.customContextMenuRequested.connect(self.show_context_menu)
        self.table_view.doubleClicked.connect(self.on_row_double_click)
        self.table_view.horizontalHeader().sectionClicked.connect(self.on_header_clicked)
        self.table_view.horizontalHeader().setStretchLastSection(False)
        self.table_view.horizontalHeader().setSectionsMovable(True)
        self.table_view.setSortingEnabled(False)
        self.table_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        main_layout.addWidget(self.table_view)

        nav_bar = QHBoxLayout()

        self.first_button = QPushButton("<<")
        self.prev_button = QPushButton("<")
        self.next_button = QPushButton(">")
        self.last_button = QPushButton(">>")

        self.first_button.clicked.connect(lambda: self.go_to_page(0))
        self.prev_button.clicked.connect(lambda: self.go_to_page(self.current_page - 1))
        self.next_button.clicked.connect(lambda: self.go_to_page(self.current_page + 1))
        self.last_button.clicked.connect(lambda: self.go_to_page(self.get_max_page()))

        self.page_label = QLabel("Page : 0 / 0")

        self.page_size_combo = QComboBox()
        self.page_size_combo.addItems(["100", "250", "500", "1000"])
        self.page_size_combo.currentTextChanged.connect(self.change_page_size)

        nav_bar.addWidget(self.first_button)
        nav_bar.addWidget(self.prev_button)
        nav_bar.addWidget(self.page_label)
        nav_bar.addWidget(self.next_button)
        nav_bar.addWidget(self.last_button)
        nav_bar.addStretch()
        nav_bar.addWidget(QLabel("Lignes / page"))
        nav_bar.addWidget(self.page_size_combo)

        main_layout.addLayout(nav_bar)

        self.setStatusBar(QStatusBar(self))

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedWidth(220)
        self.statusBar().addPermanentWidget(self.progress_bar)

        self.statusBar().showMessage("Prêt")

    def _load_saved_preferences(self) -> None:
        separator = self.settings.get_last_separator()
        encoding = self.settings.get_last_encoding()
        ignore_errors = self.settings.get_ignore_errors()

        idx = self.separator_combo.findText(separator)
        if idx >= 0:
            self.separator_combo.setCurrentIndex(idx)

        idx = self.encoding_combo.findText(encoding)
        if idx >= 0:
            self.encoding_combo.setCurrentIndex(idx)

        self.ignore_errors_checkbox.setChecked(ignore_errors)

    def _selected_separator(self) -> str:
        return self.separator_combo.currentText().replace("\\t", "\t")

    def _selected_encoding(self) -> str:
        return self.encoding_combo.currentText()

    def _selected_ignore_errors(self) -> bool:
        return self.ignore_errors_checkbox.isChecked()

    def on_import_click(self) -> None:
        start_dir = self.settings.get_last_directory() or str(Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Ouvrir un CSV",
            start_dir,
            "CSV (*.csv *.txt);;Tous les fichiers (*)",
        )
        if not path:
            return

        self.settings.set_last_directory(str(Path(path).resolve().parent))
        self.settings.set_last_separator(self.separator_combo.currentText())
        self.settings.set_last_encoding(self._selected_encoding())
        self.settings.set_ignore_errors(self._selected_ignore_errors())

        self.load_file(path)

    def load_file(self, csv_path: str) -> None:
        self.current_csv_path = csv_path
        db_path = csv_path + ".duckdb"
        self.db.connect(db_path)

        separator = self._selected_separator()
        encoding = self._selected_encoding()
        ignore_errors = self._selected_ignore_errors()

        if self.db.is_cache_valid(csv_path, separator, encoding, ignore_errors):
            self.db.get_columns()
            self._reset_view_state_for_new_file()
            self._update_file_label()
            self._update_filter_chips()
            self.statusBar().showMessage("Cache DuckDB réutilisé.", 5000)
            self.refresh_data()
            return

        message = "Reconstruction du cache DuckDB en cours…"
        if ignore_errors:
            message += " Les lignes défectueuses seront ignorées."
        self._set_busy(True, message)

        self.worker = DbWorker(self.db.import_csv, csv_path, separator, encoding, ignore_errors)
        self.worker.finished.connect(self._on_import_finished)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def _reset_view_state_for_new_file(self) -> None:
        self.current_page = 0
        self.total_count = 0
        self.sort_col = None
        self.sort_order = "ASC"
        self.filters = []
        self.search_text = ""
        self.search_edit.clear()

    def _on_import_finished(self, _: Any) -> None:
        self._set_busy(False)
        self._reset_view_state_for_new_file()
        self._update_file_label()
        self._update_filter_chips()
        self.statusBar().showMessage("Cache DuckDB reconstruit et fichier chargé.", 5000)
        self.refresh_data()

    def _update_file_label(self) -> None:
        if not self.current_csv_path:
            self.file_info_label.setText("Aucun fichier chargé")
            return
        filename = os.path.basename(self.current_csv_path)
        self.file_info_label.setText(f"Fichier : {filename}")

    def get_max_page(self) -> int:
        if self.total_count <= 0:
            return 0
        return (self.total_count - 1) // self.page_size

    def refresh_data(self) -> None:
        if not self.db.columns:
            self.db.get_columns()

        if not self.db.columns:
            self.table_view.setModel(None)
            self.total_count = 0
            self.page_label.setText("Page : 0 / 0")
            self._update_navigation_state()
            return

        self.search_text = self.search_edit.text().strip()
        self._set_busy(True, "Chargement des données…")

        current_page = self.current_page
        page_size = self.page_size
        sort_col = self.sort_col
        sort_order = self.sort_order
        search_text = self.search_text
        filters = list(self.filters)

        def task() -> dict[str, Any]:
            count = self.db.get_count(search_text, filters)
            max_page = 0 if count <= 0 else (count - 1) // page_size
            page = min(current_page, max_page)
            rows = self.db.fetch_page(
                page_size=page_size,
                offset=page * page_size,
                sort_col=sort_col,
                sort_order=sort_order,
                search_text=search_text,
                filters=filters,
            )
            return {"count": count, "page": page, "rows": rows}

        self.worker = DbWorker(task)
        self.worker.finished.connect(self._on_refresh_finished)
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def _on_refresh_finished(self, payload: dict[str, Any]) -> None:
        self._set_busy(False)
        self.total_count = int(payload["count"])
        self.current_page = int(payload["page"])
        rows = payload["rows"]

        model = CSVTableModel(rows, self.db.columns)
        self.table_view.setModel(model)
        self.table_view.resizeColumnsToContents()

        if self.total_count == 0:
            self.page_label.setText("Page : 0 / 0 (0 ligne)")
        else:
            self.page_label.setText(
                f"Page : {self.current_page + 1} / {self.get_max_page() + 1} ({self.total_count:,} lignes)"
            )

        self._update_navigation_state()

    def _update_navigation_state(self) -> None:
        has_data = self.total_count > 0
        max_page = self.get_max_page()
        self.first_button.setEnabled(has_data and self.current_page > 0)
        self.prev_button.setEnabled(has_data and self.current_page > 0)
        self.next_button.setEnabled(has_data and self.current_page < max_page)
        self.last_button.setEnabled(has_data and self.current_page < max_page)
        self.add_filter_button.setEnabled(bool(self.db.columns))
        self.reset_button.setEnabled(bool(self.db.columns))
        self.export_button.setEnabled(bool(self.db.columns))

    def go_to_page(self, page: int) -> None:
        if self.total_count <= 0:
            return
        target = max(0, min(int(page), self.get_max_page()))
        if target == self.current_page:
            return
        self.current_page = target
        self.refresh_data()

    def change_page_size(self, text: str) -> None:
        self.page_size = int(text)
        self.current_page = 0
        if self.db.columns:
            self.refresh_data()

    def apply_search(self) -> None:
        if not self.db.columns:
            return
        self.current_page = 0
        self.refresh_data()

    def on_header_clicked(self, logical_index: int) -> None:
        if not self.db.columns or logical_index >= len(self.db.columns):
            return
        clicked_col = self.db.columns[logical_index]
        if self.sort_col == clicked_col:
            self.sort_order = "DESC" if self.sort_order == "ASC" else "ASC"
        else:
            self.sort_col = clicked_col
            self.sort_order = "ASC"
        self.current_page = 0
        self.refresh_data()

    def add_filter(self) -> None:
        if not self.db.columns:
            return
        dialog = FilterDialog(self.db.columns, self)
        if dialog.exec():
            self.filters.append(dialog.get_filter())
            self.current_page = 0
            self._update_filter_chips()
            self.refresh_data()

    def remove_filter(self, index: int) -> None:
        if 0 <= index < len(self.filters):
            self.filters.pop(index)
            self.current_page = 0
            self._update_filter_chips()
            self.refresh_data()

    def reset_filters(self) -> None:
        self.filters = []
        self.search_text = ""
        self.search_edit.clear()
        self.current_page = 0
        self._update_filter_chips()
        if self.db.columns:
            self.refresh_data()
        else:
            self.table_view.setModel(None)
            self.page_label.setText("Page : 0 / 0")
            self._update_navigation_state()

    def _update_filter_chips(self) -> None:
        while self.filter_layout.count():
            item = self.filter_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        if not self.filters:
            label = QLabel("Aucun filtre actif")
            label.setStyleSheet("color: #666;")
            self.filter_layout.addWidget(label)
            self.filter_layout.addStretch(1)
            return

        for idx, flt in enumerate(self.filters):
            text = f"{flt['column']} {flt['op']}"
            if flt.get("value"):
                text += f" {flt['value']}"
            button = QPushButton("✕ " + text)
            button.setStyleSheet(
                "QPushButton { background: #e7e7e7; border-radius: 10px; padding: 4px 10px; }"
            )
            button.clicked.connect(lambda checked=False, i=idx: self.remove_filter(i))
            self.filter_layout.addWidget(button)
        self.filter_layout.addStretch(1)

    def show_context_menu(self, pos) -> None:
        model = self.table_view.model()
        if model is None:
            return

        index = self.table_view.indexAt(pos)
        menu = QMenu(self)

        copy_cell_action = menu.addAction("Copier la cellule")
        copy_row_action = menu.addAction("Copier la ligne")
        copy_selection_action = menu.addAction("Copier la sélection (TSV)")

        chosen = menu.exec(self.table_view.viewport().mapToGlobal(pos))
        if chosen is None:
            return

        if chosen == copy_cell_action:
            if index.isValid():
                self.copy_cell(index.row(), index.column())
        elif chosen == copy_row_action:
            if index.isValid():
                self.copy_row(index.row())
        elif chosen == copy_selection_action:
            self.copy_selection()

    def copy_cell(self, row: int, column: int) -> None:
        model = self.table_view.model()
        if not isinstance(model, CSVTableModel):
            return
        pyperclip.copy(model.raw_text(row, column))
        self.statusBar().showMessage("Cellule copiée.", 2500)

    def copy_row(self, row: int) -> None:
        model = self.table_view.model()
        if not isinstance(model, CSVTableModel):
            return
        values = model.raw_row(row)
        pyperclip.copy("\t".join("" if value is None else str(value) for value in values))
        self.statusBar().showMessage("Ligne copiée.", 2500)

    def copy_selection(self) -> None:
        model = self.table_view.model()
        selection_model = self.table_view.selectionModel()
        if not isinstance(model, CSVTableModel) or selection_model is None:
            return

        selected_rows = selection_model.selectedRows()
        if selected_rows:
            lines = []
            for index in selected_rows:
                values = model.raw_row(index.row())
                lines.append("\t".join("" if value is None else str(value) for value in values))
            pyperclip.copy("\n".join(lines))
            self.statusBar().showMessage(f"{len(lines)} ligne(s) copiée(s).", 2500)
            return

        current = self.table_view.currentIndex()
        if current.isValid():
            self.copy_cell(current.row(), current.column())

    def keyPressEvent(self, event) -> None:
        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_C:
            self.copy_selection()
            return
        super().keyPressEvent(event)

    def on_row_double_click(self, index) -> None:
        model = self.table_view.model()
        if not isinstance(model, CSVTableModel) or not index.isValid():
            return
        dialog = DetailDialog(model.raw_row(index.row()), self.db.columns, self)
        dialog.exec()

    def export_results(self) -> None:
        if not self.db.columns:
            return

        start_dir = self.settings.get_last_directory() or str(Path.home())
        output_path, _ = QFileDialog.getSaveFileName(
            self,
            "Exporter les résultats",
            str(Path(start_dir) / "export.csv"),
            "CSV (*.csv)",
        )
        if not output_path:
            return

        self._set_busy(True, "Export en cours…")
        search_text = self.search_edit.text().strip()
        filters = list(self.filters)
        sort_col = self.sort_col
        sort_order = self.sort_order

        self.worker = DbWorker(self.db.export_csv, output_path, search_text, filters, sort_col, sort_order)
        self.worker.finished.connect(lambda _: self._on_export_finished(output_path))
        self.worker.error.connect(self.on_error)
        self.worker.start()

    def _on_export_finished(self, output_path: str) -> None:
        self._set_busy(False)
        QMessageBox.information(self, "Export terminé", f"Export créé :\n{output_path}")

    def _set_busy(self, busy: bool, message: str = "") -> None:
        self.progress_bar.setVisible(busy)
        if busy:
            self.progress_bar.setRange(0, 0)
            self.statusBar().showMessage(message or "Traitement en cours…")
        else:
            self.progress_bar.setVisible(False)
            self.statusBar().showMessage(message or "Prêt")

    def on_error(self, error_message: str) -> None:
        self._set_busy(False)
        QMessageBox.critical(self, "Erreur", error_message)

    def closeEvent(self, event) -> None:
        try:
            self.db.close()
        finally:
            super().closeEvent(event)
