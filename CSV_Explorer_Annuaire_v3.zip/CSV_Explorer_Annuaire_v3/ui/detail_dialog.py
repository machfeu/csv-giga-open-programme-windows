from __future__ import annotations

import pyperclip
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFormLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)


class DetailDialog(QDialog):
    def __init__(self, data: tuple[object, ...], columns: list[str], parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Détail de la ligne")
        self.resize(700, 520)

        layout = QVBoxLayout(self)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)

        container = QWidget()
        form = QFormLayout(container)

        for column, value in zip(columns, data):
            label = QLabel("" if value is None else str(value))
            label.setWordWrap(True)
            label.setTextInteractionFlags(Qt.TextSelectableByMouse)
            form.addRow(f"<b>{column}</b>", label)

        scroll.setWidget(container)
        layout.addWidget(scroll)

        copy_button = QPushButton("Copier la ligne complète (TSV)")
        copy_button.clicked.connect(lambda: pyperclip.copy("\t".join("" if v is None else str(v) for v in data)))
        layout.addWidget(copy_button)
