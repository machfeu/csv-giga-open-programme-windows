from __future__ import annotations

from typing import Any

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt


class CSVTableModel(QAbstractTableModel):
    def __init__(self, data: list[tuple[Any, ...]], columns: list[str], max_display_length: int = 120):
        super().__init__()
        self._data = data
        self._columns = columns
        self._max_display_length = max(20, int(max_display_length))

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self._data)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        if parent.isValid():
            return 0
        return len(self._columns)

    def _display_value(self, value: Any) -> str:
        if value is None:
            return ""
        text = str(value)
        if len(text) > self._max_display_length:
            return text[: self._max_display_length] + "…"
        return text

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole) -> Any:
        if not index.isValid():
            return None

        raw = self.raw_value(index.row(), index.column())

        if role == Qt.DisplayRole:
            return self._display_value(raw)
        if role == Qt.ToolTipRole:
            return "" if raw is None else str(raw)
        if role == Qt.TextAlignmentRole:
            return Qt.AlignLeft | Qt.AlignVCenter
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole) -> Any:
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal:
            if 0 <= section < len(self._columns):
                return self._columns[section]
            return None
        return str(section + 1)

    def raw_value(self, row: int, column: int) -> Any:
        return self._data[row][column]

    def raw_row(self, row: int) -> tuple[Any, ...]:
        return self._data[row]

    def raw_text(self, row: int, column: int) -> str:
        value = self.raw_value(row, column)
        return "" if value is None else str(value)
