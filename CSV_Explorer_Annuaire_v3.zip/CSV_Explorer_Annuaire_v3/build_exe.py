from pathlib import Path

import PyInstaller.__main__


def build() -> None:
    project_root = Path(__file__).resolve().parent
    PyInstaller.__main__.run(
        [
            str(project_root / "main.py"),
            "--name=CSV_Explorer_Annuaire",
            "--windowed",
            "--onefile",
            "--clean",
            "--noconfirm",
            "--collect-all=duckdb",
        ]
    )


if __name__ == "__main__":
    build()
