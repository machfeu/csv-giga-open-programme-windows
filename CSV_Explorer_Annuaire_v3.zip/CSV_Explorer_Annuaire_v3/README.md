# CSV Explorer Annuaire

Outil desktop Windows pour lire, filtrer, trier et exporter un gros CSV d'annuaire d'entreprises sans charger tout le fichier en RAM.

## Choix techniques

- **Interface** : PySide6 / Qt
- **Moteur de données** : DuckDB
- **Cache persistant** : un fichier `mon_fichier.csv.duckdb` est créé à côté du CSV
- **Lecture gros volume** : le CSV est matérialisé dans DuckDB pour éviter de rescanner 4 Go à chaque action
- **Recherche / tri / pagination** : exécutés en SQL
- **Fluidité UI** : import, chargement et export passent par un worker thread Qt

## Fonctions livrées

- Import d'un CSV volumineux
- Choix du séparateur : `,` `;` ou tabulation
- Choix de l'encodage : `utf-8`, `latin-1`, `utf-16`
- Option explicite pour ignorer les lignes en erreur
- Réutilisation automatique du cache si le fichier source **et** les options d'import n'ont pas changé
- Pagination 100 / 250 / 500 / 1000 lignes
- Recherche globale
- Filtres par colonne
- Tri par clic sur les en-têtes
- Copie cellule, copie ligne, copie sélection TSV
- Export des résultats filtrés vers CSV
- Détail complet d'une ligne au double-clic

## Arborescence

```text
CSV_Explorer_Annuaire_v3/
├── main.py
├── requirements.txt
├── README.md
├── build_exe.py
├── core/
│   ├── __init__.py
│   ├── database.py
│   ├── settings.py
│   └── worker.py
└── ui/
    ├── __init__.py
    ├── detail_dialog.py
    ├── filter_dialog.py
    ├── main_window.py
    └── table_model.py
```

## Mise en route rapide

### 1) Installer Python

Installe Python 3.11 ou 3.12 sur Windows, puis coche l'option d'ajout au `PATH`.

### 2) Ouvrir un terminal dans le dossier du projet

Dans l'Explorateur Windows :
- décompresse l'archive ZIP
- ouvre le dossier du projet
- clique dans la barre d'adresse
- tape `cmd`
- valide

### 3) Créer un environnement virtuel

```bash
python -m venv .venv
```

### 4) Activer l'environnement

```bash
.venv\Scripts\activate
```

### 5) Installer les dépendances

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 6) Lancer le logiciel

```bash
python main.py
```

## Utilisation

1. Clique sur **Importer un CSV**
2. Choisis le séparateur et l'encodage adaptés
3. Laisse **Ignorer les lignes en erreur** décoché par défaut
4. Au premier chargement, le cache `.duckdb` est construit
5. Aux ouvertures suivantes, si le CSV n'a pas changé et si les options d'import sont identiques, le cache est réutilisé

## Générer un .exe Windows

Une fois les dépendances installées :

```bash
python build_exe.py
```

L'exécutable sera généré dans le dossier `dist/`.

## Notes importantes

- Le premier import d'un CSV de plusieurs gigas peut prendre un peu de temps : c'est normal.
- La recherche globale sur toutes les colonnes peut être lourde sur un très gros annuaire.
- Le cache est invalidé si :
  - la taille du fichier change
  - la date de modification change
  - le séparateur change
  - l'encodage change
  - l'option `ignore_errors` change
- L'option `ignore_errors` peut sauter des lignes défectueuses. Elle est laissée sous contrôle utilisateur.

## Dépannage rapide

### Le CSV ne s'ouvre pas
- vérifie le bon séparateur
- vérifie le bon encodage
- essaye de recocher ou décocher l'option d'erreurs selon l'état du fichier

### Le chargement est lent
- le premier import construit la base locale
- les ouvertures suivantes doivent être plus rapides grâce au cache

### L'export échoue
- vérifie que le fichier cible n'est pas déjà ouvert dans Excel
- vérifie que tu as les droits d'écriture sur le dossier de destination
